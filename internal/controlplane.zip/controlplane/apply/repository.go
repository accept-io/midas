package apply

// Repository is the future persistence seam for control-plane apply.
// Milestone 4.5: marker interface only.
// Milestone 5: add create operations.
type Repository interface{}
